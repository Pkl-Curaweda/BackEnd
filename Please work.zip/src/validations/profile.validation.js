const { z } = require('zod');
const validate = require('../middlewares/validation');
const { recordUnique } = require('../utils/db-validation')

const phoneInputScheme = z.object({
  body: z.object({
    phone: z.string({
      required_error: 'Phone Number is required',
    }),
  }),
});

const emailInputScheme = z.object({
  body: z.object({
    email: z.string({
      required_error: 'Email is required',
    }),
  }),
});

const nikInputScheme = z.object({
  body: z.object({
    nik: z.string({
      required_error: 'NIK is required',
    }),
  }),
});

const updateProfileValidation = validate(
  id => ({
    name: z.string(),
    gender: z.enum(['MALE', 'FEMALE']),
    phone: z.string(),
    picture: z.string().optional(),
    birthday: z.coerce.date().optional(),
    nik: z.string().optional(),
    email: z.string().email().refine(recordUnique('user', 'email', id), {
      message: 'Email already exist'
    }),
  })
)

const phoneValidation = validate(phoneInputScheme);
const emailValidation = validate(emailInputScheme);
const nikValidation = validate(nikInputScheme);

module.exports = { phoneValidation, emailValidation, nikValidation, updateProfileValidation };
